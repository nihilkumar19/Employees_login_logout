<?php
session_start();

if (!isset($_SESSION['employee_id'])) {
    header("Location: login.php");
    exit();
}

// Retrieve the employee's username from the session
$username = $_SESSION['username'];

echo "Welcome, " . htmlspecialchars($username) . "!";

?>

<style>
    /* Add some basic styling to center the logout link */
    body {
        font-family: Arial, sans-serif;
        text-align: center;
    }

    a {
        text-decoration: none;
        color: #00698f;
    }

    a:hover {
        color: #0099cc;
    }

    .logout-link {
        display: block;
        margin: 20px auto;
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        background-color: #f0f0f0;
        cursor: pointer;
    }

    .logout-link:hover {
        background-color: #e0e0e0;
    }
</style>

<a href="logout.php" class="logout-link">Logout</a>