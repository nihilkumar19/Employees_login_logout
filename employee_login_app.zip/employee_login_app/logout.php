<?php
require 'db.php';
session_start();

if (isset($_SESSION['employee_id'])) {
    $employee_id = $_SESSION['employee_id'];

    // Log the logout time
    $stmt = $conn->prepare("UPDATE logins SET logout_time = NOW() WHERE employee_id = :employee_id AND logout_time IS NULL");
    $stmt->bindParam(':employee_id', $employee_id);
    $stmt->execute();

    session_destroy();
    echo "Logout successful!";
} else {
    echo "No user is logged in.";
}
?>
