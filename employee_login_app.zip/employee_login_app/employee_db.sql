-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jun 10, 2024 at 08:57 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `employee_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `username`, `password`) VALUES
(3, 'Zommer', '$2y$10$7gCKjG85DMxzoMFLKUsbGO8lS0YLwiCP75Pbkuj7OqfvVfTtlZYxO'),
(4, 'Nihil', '$2y$10$GzeuyJnSmDtwjhRbWEWh8eBlE2lrgXPu9BLh.3Sc/b3e9onsHtO/e'),
(5, 'hello', '$2y$10$8mp.84zC1naWz2jrWvy0QOH7pkQBpXgTt/gNNa3/7p8iU0tW/.o4a'),
(6, 'ram', '$2y$10$MrzUj3cuhVWb1hZvxfHrgeeno075yBjhwE00EglCU7PrgF9nrG.l6'),
(8, 'aaa', '$2y$10$bu795ExbzOIWJFILXdLydepSUBDhAQz0TaUik.ZN2iDxrBK3QU2A6'),
(9, 'bbb', '$2y$10$a.WnYO7nJra5v9mc6bR0LOmnv0F93pjTnqCzPQf3bFeFnsA0JWP6m'),
(10, 'love', '$2y$10$qZA6wP24AduckFLdHCoW4.aODv8cw7tsaV14olsL51HPS4AQ5ObLK'),
(11, 'testuser', '$2y$10$7RANMr.YF1DrnEWGigeHQef1aqwFx3CnUPboJX0VEuafnZRmeKWUC'),
(12, 'Anand', '$2y$10$cjjtZSf4.jKN3H2wgh.qvOLGk7u4wKiKkOHFiwpdO7QknP26Pa7IG'),
(16, 'Nihilk', '$2y$10$mgmBr.81QHpHdQKsjAQCiO06ZmlknFrd.JxOTvQuHLddvA5ZCETB2');

-- --------------------------------------------------------

--
-- Table structure for table `logins`
--

CREATE TABLE `logins` (
  `id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `login_time` datetime DEFAULT NULL,
  `logout_time` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `logins`
--

INSERT INTO `logins` (`id`, `employee_id`, `login_time`, `logout_time`) VALUES
(1, 3, '2024-06-09 16:20:27', NULL),
(2, 4, '2024-06-09 16:21:12', '2024-06-10 11:59:59'),
(3, 5, '2024-06-09 16:23:22', NULL),
(4, 6, '2024-06-09 16:25:19', NULL),
(6, 8, '2024-06-09 16:33:52', '2024-06-09 16:42:17'),
(7, 9, '2024-06-09 16:35:08', '2024-06-09 16:41:54'),
(8, 9, '2024-06-09 16:41:48', '2024-06-09 16:41:54'),
(9, 8, '2024-06-09 16:42:15', '2024-06-09 16:42:17'),
(10, 10, '2024-06-09 16:42:47', '2024-06-09 16:42:52'),
(11, 9, '2024-06-09 16:48:10', '2024-06-09 16:49:39'),
(12, 9, '2024-06-09 16:49:46', '2024-06-09 16:49:53'),
(13, 9, '2024-06-09 16:50:51', '2024-06-09 16:52:48'),
(14, 9, '2024-06-09 16:52:59', '2024-06-09 16:53:01'),
(15, 9, '2024-06-09 16:54:32', '2024-06-09 16:54:37'),
(16, 8, '2024-06-09 16:55:07', '2024-06-09 16:55:19'),
(17, 9, '2024-06-09 16:55:43', '2024-06-09 16:56:08'),
(18, 9, '2024-06-09 16:56:16', '2024-06-09 17:00:21'),
(19, 9, '2024-06-09 17:00:17', '2024-06-09 17:00:21'),
(20, 9, '2024-06-09 17:02:16', '2024-06-09 17:02:19'),
(21, 11, '2024-06-09 17:08:12', '2024-06-09 17:10:30'),
(22, 12, '2024-06-10 11:09:33', '2024-06-10 11:34:23'),
(23, 16, '2024-06-10 11:34:39', '2024-06-10 11:45:30'),
(24, 4, '2024-06-10 11:45:40', '2024-06-10 11:59:59');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `logins`
--
ALTER TABLE `logins`
  ADD PRIMARY KEY (`id`),
  ADD KEY `employee_id` (`employee_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `logins`
--
ALTER TABLE `logins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `logins`
--
ALTER TABLE `logins`
  ADD CONSTRAINT `logins_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
