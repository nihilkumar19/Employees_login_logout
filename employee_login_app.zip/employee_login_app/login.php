<?php
require 'db.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, password FROM employees WHERE username = :username");
    $stmt->bindParam(':username', $username);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['employee_id'] = $user['id'];
        $_SESSION['username'] = $username; // Store the username in the session

        // Log the login time
        $stmt = $conn->prepare("INSERT INTO logins (employee_id, login_time) VALUES (:employee_id, NOW())");
        $stmt->bindParam(':employee_id', $user['id']);
        $stmt->execute();

        header("Location: protected.php");
        exit();
    } else {
        echo "Invalid username or password.";
    }
}
?>


<style>
  /* Add some basic styling to our form */
  form {
    max-width: 300px;
    margin: 40px auto;
    padding: 20px;
    background-color: #f9f9f9;
    border: 1px solid #ccc;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  }

  /* Style our input fields */
  input[type="text"], input[type="password"] {
    width: 100%;
    height: 40px;
    margin-bottom: 20px;
    padding: 10px;
    border: 1px solid #ccc;
  }

  /* Add some focus styles to our input fields */
  input[type="text"]:focus, input[type="password"]:focus {
    border-color: #aaa;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
  }

  /* Style our submit button */
  input[type="submit"] {
    width: 100%;
    height: 40px;
    background-color: #4CAF50;
    color: #fff;
    padding: 10px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
  }

  /* Add some hover styles to our submit button */
  input[type="submit"]:hover {
    background-color: #3e8e41;
  }
</style>

<form method="POST" action="">
    Username: <input type="text" name="username" required>
    Password: <input type="password" name="password" required>
    <input type="submit" value="Login">
</form>
